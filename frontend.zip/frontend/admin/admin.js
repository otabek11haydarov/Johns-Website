let currentStudents = [];
let editingStudentId = null;


const sectionLabels = {
  dashboard: "Dashboard",
  library: "Library",
  users: "Students",
};



const navLinks = document.querySelectorAll(".nav-link[data-section]");
const sections = document.querySelectorAll(".section");
const headerTitle = document.getElementById("headerTitle");
const sidebar = document.getElementById("sidebar");
const sidebarOverlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");
const sidebarClose = document.getElementById("sidebarClose");
const themeToggle = document.getElementById("themeToggle");
const THEME_KEY = "edu-dashboard-theme";
const LOGIN_PAGE = "../auth/login.html";

function redirectToLogin() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  localStorage.removeItem("userId");
  if (!window.location.pathname.includes('/auth/login')) {
    window.location.replace(LOGIN_PAGE);
  }
}

function ensureAdminAccess() {
  return enforceRole("ADMIN");
}

function applyTheme(theme) {
  const isDark = theme === "dark";
  document.body.classList.toggle("dark-mode", isDark);
  if (themeToggle) {
    themeToggle.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
    themeToggle.setAttribute("title", isDark ? "Light mode" : "Dark mode");
  }
}

function toggleTheme() {
  const nextTheme = document.body.classList.contains("dark-mode") ? "light" : "dark";
  localStorage.setItem(THEME_KEY, nextTheme);
  applyTheme(nextTheme);
}

function createStatusBadge(status) {
  const normalized = (status || "").toLowerCase();
  return `<span class="status-badge ${normalized}">${status || "-"}</span>`;
}

function renderDashboardActivity(activity) {
  const tbody = document.getElementById("dashboard-activity-tbody");

  if (!activity || activity.length === 0){
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--text-secondary);">Hozircha baholangan o'quvchilar yo'q.</td></tr>`;
  }else { 
    tbody.innerHTML = activity
    .map(
      (item) => `
        <tr>
          <td>${item.rank}</td>
          <td>${item.name}</td>
          <td>${item.email}</td>
          <td>${item.group}</td>
          <td>${item.score}</td>
        </tr>`,
    )
    .join("");
  }
}

function renderStudents(students) {
  currentStudents = students || [];
  const tbody = document.getElementById("users-tbody");

  if (!students || students.length === 0){
    tbody.innerHTML = `<tr><td colspan="7">No students found.</td></tr>`;
  }else {
    tbody.innerHTML = students.map((item) => {
      const joinedDate = new Date(item.createdAt).toLocaleDateString();
      const program = item.group && item.group.label ? item.group.label : "-";
      const name = item.fullName || "Ism ko'rsatilmagan";
      return `
        <tr>
          <td><strong>${item.username}</strong></td>
          <td>${name}</td>
          <td>${item.email}</td>
          <td>${program}</td>
          <td>${joinedDate}</td>
          <td>${createStatusBadge(item.status)}</td>
          <td>
            <div style="display: flex; gap: 8px;">
              <button class="btn btn-primary" style="padding: 4px 10px; font-size: 12px; min-height: unset; height: 28px;" onclick="editStudent('${item.id}')">Edit</button>
              <button class="btn btn-secondary" style="padding: 4px 10px; font-size: 12px; min-height: unset; height: 28px; background-color: transparent; color: #fff; border: 1px solid rgba(255, 255, 255, 0.2);" onclick="deleteStudent('${item.id}')">Delete</button>
            </div>
          </td>
        </tr>`;
    }).join("");
  } 
}

function renderGroups(groups) {
  
  const statsGrid = document.getElementById("stats-grid");
  const palette = ["blue", "green", "purple", "yellow", "red"];
  const fallbackGroups = [
    { level: "A1", label: "Group A1", title: "Vocabulary Basics", description: "Simple Present Tense", students: 25 },
    { level: "B1", label: "Group B1", title: "Past Simple", description: "Past Continuous", students: 28 },
    { level: "C1", label: "Group C1", title: "Reading Advanced", description: "Reading Practice 3", students: 24 },
    { level: "A2", label: "Group A2", title: "Article: My Daily Routine", description: "Article: Healthy Habits", students: 26 },
    { level: "B2", label: "Group B2", title: "Listening Basics", description: "Listening Practice 2", students: 25 },
  ];
  const source = Array.isArray(groups) && groups.length ? groups : fallbackGroups;

  if (!statsGrid) {
    return;
  }

  statsGrid.innerHTML = source
    .map(
      (item, index) => {
        const completed = item.completed ?? 18 + (index % 5);
        const pending = item.pending ?? Math.max(3, 7 - (index % 4));
        const accuracy = item.accuracy ?? 86 - (index % 4);
        const studentCount = item.students ?? item.studentCount ?? item.count ?? 24 + index;
        const level = item.level || `G${index + 1}`;
        const label = item.label || item.name || `Group ${level}`;
        const lastTask = item.title || item.lastTask || "Vocabulary Basics";
        const todayTask = item.description || item.todayTask || "Simple Present Tense";

        return `
        <a class="panel group-card ${palette[index % palette.length]}" href="../group/group.html?level=${encodeURIComponent(level)}">
          <div class="group-card-header">
            <div class="group-title">
              <span class="group-badge">${escapeHtml(level)}</span>
              <strong>${escapeHtml(label)}</strong>
            </div>
            <span class="group-meta">&#128101; ${escapeHtml(studentCount)} Students</span>
          </div>

          <div class="lesson-pair">
            <div class="lesson-item">
              <span>Last Task</span>
              <div class="lesson-row">
                <span class="lesson-icon">&#128214;</span>
                <strong>${escapeHtml(lastTask)}</strong>
              </div>
            </div>
            <div class="lesson-item">
              <span>Today's Task</span>
              <div class="lesson-row">
                <span class="lesson-icon">&#128214;</span>
                <strong>${escapeHtml(todayTask)}</strong>
              </div>
            </div>
          </div>

          <div class="group-stats">
            <div class="group-stat">
              <span>Completed</span>
              <strong>${escapeHtml(completed)}</strong>
            </div>
            <div class="group-stat pending">
              <span>Pending</span>
              <strong>${escapeHtml(pending)}</strong>
            </div>
            <div class="group-stat accuracy">
              <span>Accuracy</span>
              <strong>${escapeHtml(accuracy)}%</strong>
            </div>
          </div>
        </a>`;
      },
    )
    .join("");
}

function closeSidebar() {
  sidebar.classList.remove("open");
  sidebarOverlay.classList.remove("open");
}

function openSidebar() {
  sidebar.classList.add("open");
  sidebarOverlay.classList.add("open");
}

function showSection(name) {
  sections.forEach((section) => section.classList.remove("active"));
  navLinks.forEach((link) => link.classList.remove("active"));

  const target = document.getElementById(`section-${name}`);
  if (target) {
    target.classList.add("active");
  }

  const activeLink = document.querySelector(`.nav-link[data-section="${name}"]`);
  if (activeLink) {
    activeLink.classList.add("active");
  }

  if (headerTitle) {
    headerTitle.textContent = sectionLabels[name] || "Dashboard";
  }

  if (name === "library") {
    loadBooks();
  }

  closeSidebar();
}

navLinks.forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    showSection(link.dataset.section);
  });
});

sidebarToggle?.addEventListener("click", openSidebar);
sidebarClose?.addEventListener("click", closeSidebar);
sidebarOverlay?.addEventListener("click", closeSidebar);
themeToggle?.addEventListener("click", toggleTheme);

function clearFormErrors() {
  document.querySelectorAll(".field-error").forEach((el) => {
    el.textContent = "";
  });

  document.querySelectorAll(".modal-form input, .modal-form textarea, .modal-form select").forEach((el) => {
    el.classList.remove("invalid");
  });
}

const DEFAULT_BOOK_IMAGE = "default-book.png";
const DEFAULT_BOOK_PREVIEW = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 600">
    <defs>
      <linearGradient id="bookGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#d97b41" />
        <stop offset="100%" stop-color="#c95a52" />
      </linearGradient>
    </defs>
    <rect width="480" height="600" rx="36" fill="url(#bookGradient)" />
    <rect x="34" y="34" width="412" height="532" rx="28" fill="rgba(255,255,255,0.12)" />
    <text x="52" y="118" fill="#fff7f1" font-family="Segoe UI, Arial, sans-serif" font-size="34" font-weight="700">Library</text>
    <text x="52" y="210" fill="#ffffff" font-family="Segoe UI, Arial, sans-serif" font-size="46" font-weight="700">Default Book</text>
    <text x="52" y="520" fill="#fff7f1" font-family="Segoe UI, Arial, sans-serif" font-size="24">John Academy</text>
  </svg>
`)}`;

const bookGrid = document.getElementById("book-grid");
const addBookBtn = document.getElementById("addBookBtn");
const bookSearchInput = document.getElementById("bookSearchInput");
const bookLevelFilter = document.getElementById("bookLevelFilter");
const bookModalOverlay = document.getElementById("bookModalOverlay");
const bookForm = document.getElementById("bookForm");
const bookModalTitle = document.getElementById("bookModalTitle");
const bookModalSubmit = document.getElementById("bookModalSubmit");
const bookPdfInput = document.getElementById("bookPdf");
const bookPdfHint = document.getElementById("bookPdfHint");
const bookImageInput = document.getElementById("bookImage");
const bookImagePreview = document.getElementById("bookImagePreview");
const deleteBookModalOverlay = document.getElementById("deleteBookModalOverlay");
const deleteBookModalConfirm = document.getElementById("deleteBookModalConfirm");

let pendingBookDeleteId = null;
let currentBookImageValue = DEFAULT_BOOK_IMAGE;
let currentBookPdfValue = "";
let currentBookObjectUrl = "";

function normalizeBookLevel(level) {
  return (level || "").toUpperCase().startsWith("CEFR") ? "CEFR" : level || "IELTS";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function resolveBookImage(image) {
  if (!image || image === DEFAULT_BOOK_IMAGE) {
    return DEFAULT_BOOK_PREVIEW;
  }

  if (image.startsWith("data:") || image.startsWith("http")) {
    return image;
  }

  return `${BASE_URL}/${image.replace(/^\/+/, "")}`;
}

function getPdfFileName(pdfPath) {
  return (pdfPath || "").split("/").pop() || "No PDF selected";
}

function updateBookPreview(src) {
  bookImagePreview.src = src || DEFAULT_BOOK_PREVIEW;
}

function resetBookObjectUrl() {
  if (currentBookObjectUrl) {
    URL.revokeObjectURL(currentBookObjectUrl);
    currentBookObjectUrl = "";
  }
}

function renderBooks(payload) {
  if (!bookGrid) {
    return;
  }

  const books = Array.isArray(payload?.data) ? payload.data : [];
  const searchValue = (bookSearchInput?.value || "").trim().toLowerCase();
  const levelValue = bookLevelFilter?.value || "All";

  const filteredBooks = books.filter((book) => {
    const matchesSearch = (book.title || "").toLowerCase().includes(searchValue);
    const matchesLevel =
      levelValue === "All" ? true : normalizeBookLevel(book.level) === levelValue;

    return matchesSearch && matchesLevel;
  });

  if (!filteredBooks.length) {
    bookGrid.innerHTML = `<div class="book-empty">No books found for the current search or level filter.</div>`;
    return;
  }

  bookGrid.innerHTML = filteredBooks
    .map(
      (book) => `
        <article
          class="panel book-card"
          data-book-card="true"
          data-book-id="${book.id}"
          data-book-title="${escapeHtml(book.title)}"
          data-book-author="${escapeHtml(book.author)}"
          data-book-level="${escapeHtml(book.level)}"
          data-book-pdf="${escapeHtml(book.pdf)}"
          data-book-image="${escapeHtml(book.image || DEFAULT_BOOK_IMAGE)}"
        >
          <img
            class="book-card-cover"
            src="${escapeHtml(resolveBookImage(book.image))}"
            alt="${escapeHtml(book.title)} cover"
            onerror="this.onerror=null;this.src='${DEFAULT_BOOK_PREVIEW}'"
          />
          <div class="book-card-body">
            <div class="book-card-copy">
              <h3>${escapeHtml(book.title)}</h3>
              <p>${escapeHtml(book.author)}</p>
            </div>

            <div class="book-card-meta">
              <span class="book-badge">${escapeHtml(book.level)}</span>
              <span class="book-badge">PDF Ready</span>
            </div>

            <div class="book-card-actions">
              <button class="btn btn-edit btn-shine book-action" type="button" data-book-action="edit">
                Edit
              </button>
              <button class="btn btn-danger btn-shine book-action" type="button" data-book-action="delete">
                Delete
              </button>
            </div>
          </div>
        </article>
      `,
    )
    .join("");
}

async function loadBooks() {
  if (!bookGrid) {
    return;
  }

  bookGrid.innerHTML = `<div class="book-empty">Loading books...</div>`;

  try {
    const res = await fetch(`${BASE_URL}/api/books`);
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || "Failed to load books.");
    }

    renderBooks(data);
  } catch (error) {
    bookGrid.innerHTML = `<div class="book-empty">Book backend is not available yet.</div>`;
  }
}

function clearBookFormErrors() {
  clearFormErrors();
  bookPdfInput?.classList.remove("invalid");
}

function clearBookFormState() {
  resetBookObjectUrl();
  currentBookImageValue = DEFAULT_BOOK_IMAGE;
  currentBookPdfValue = "";
  bookForm.reset();
  document.getElementById("bookId").value = "";
  clearBookFormErrors();
  bookPdfHint.textContent = "PDF is required for new books.";
  updateBookPreview(DEFAULT_BOOK_PREVIEW);
}

function openCreateBookModal() {
  bookModalTitle.textContent = "Add Book";
  bookModalSubmit.textContent = "Create Book";
  clearBookFormState();
  bookModalOverlay.classList.add("open");
}

function closeBookModal() {
  bookModalOverlay.classList.remove("open");
  clearBookFormState();
}

function openEditBookModal(trigger) {
  const card = trigger.closest("[data-book-card]");
  if (!card) {
    return;
  }

  bookModalTitle.textContent = "Edit Book";
  bookModalSubmit.textContent = "Save Changes";
  clearBookFormErrors();
  resetBookObjectUrl();
  bookForm.reset();

  document.getElementById("bookId").value = card.dataset.bookId || "";
  document.getElementById("bookTitle").value = card.dataset.bookTitle || "";
  document.getElementById("bookAuthor").value = card.dataset.bookAuthor || "";
  document.getElementById("bookLevel").value = card.dataset.bookLevel || "";
  currentBookPdfValue = card.dataset.bookPdf || "";
  currentBookImageValue = card.dataset.bookImage || DEFAULT_BOOK_IMAGE;

  bookPdfHint.textContent = `Current PDF: ${getPdfFileName(currentBookPdfValue)}`;
  updateBookPreview(resolveBookImage(currentBookImageValue));
  bookModalOverlay.classList.add("open");
}

function openDeleteBookModal(trigger) {
  const card = trigger.closest("[data-book-card]");
  if (!card) {
    return;
  }

  pendingBookDeleteId = card.dataset.bookId;
  document.getElementById("deleteBookName").textContent = card.dataset.bookTitle || "this book";
  deleteBookModalOverlay.classList.add("open");
}

function closeDeleteBookModal() {
  deleteBookModalOverlay.classList.remove("open");
  pendingBookDeleteId = null;
}

function setBookFieldError(fieldId, errId, message) {
  const input = document.getElementById(fieldId);
  const err = document.getElementById(errId);

  if (input) {
    input.classList.add("invalid");
  }

  if (err) {
    err.textContent = message;
  }
}

function validateBookForm() {
  clearBookFormErrors();
  let valid = true;

  const title = document.getElementById("bookTitle").value.trim();
  const author = document.getElementById("bookAuthor").value.trim();
  const level = document.getElementById("bookLevel").value;
  const hasPdfFile = Boolean(bookPdfInput.files?.[0]);
  const hasExistingPdf = Boolean(currentBookPdfValue);

  if (!title) {
    setBookFieldError("bookTitle", "book-err-title", "Book title is required.");
    valid = false;
  }

  if (!author) {
    setBookFieldError("bookAuthor", "book-err-author", "Author is required.");
    valid = false;
  }

  if (!level) {
    setBookFieldError("bookLevel", "book-err-level", "Please select a level.");
    valid = false;
  }

  if (!hasPdfFile && !hasExistingPdf) {
    setBookFieldError("bookPdf", "book-err-pdf", "PDF is required.");
    valid = false;
  }

  return valid;
}

function buildBookPayload() {
  const formData = new FormData();

  formData.append("title", document.getElementById("bookTitle").value.trim());
  formData.append("author", document.getElementById("bookAuthor").value.trim());
  formData.append("level", document.getElementById("bookLevel").value);

  if (bookPdfInput.files?.[0]) {
    formData.append("pdf", bookPdfInput.files[0]);
  }

  if (bookImageInput.files?.[0]) {
    formData.append("image", bookImageInput.files[0]);
  }

  return formData;
}

async function onCreateBook(data) {
  const response = await fetch(`${BASE_URL}/api/books`, {
    method: "POST",
    body: data,
  });

  const value = await response.json();
  if (!response.ok) {
    throw new Error(value.message || "Failed to create book.");
  }

  alert(value.message);
}

async function onUpdateBook(id, data) {
  const response = await fetch(`${BASE_URL}/api/books/${id}`, {
    method: "PUT",
    body: data,
  });

  const value = await response.json();
  if (!response.ok) {
    throw new Error(value.message || "Failed to update book.");
  }

  alert(value.message);
}

async function onDeleteBook(id) {
  const response = await fetch(`${BASE_URL}/api/books/${id}`, {
    method: "DELETE",
  });

  const value = await response.json();
  if (!response.ok) {
    throw new Error(value.message || "Failed to delete book.");
  }

  alert(value.message);
}

addBookBtn?.addEventListener("click", openCreateBookModal);

bookSearchInput?.addEventListener("input", loadBooks);
bookLevelFilter?.addEventListener("change", loadBooks);

bookGrid?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-book-action]");
  if (!button) {
    return;
  }

  const action = button.dataset.bookAction;

  if (action === "edit") {
    openEditBookModal(button);
  }

  if (action === "delete") {
    openDeleteBookModal(button);
  }
});

document.getElementById("bookModalClose")?.addEventListener("click", closeBookModal);
document.getElementById("bookModalCancel")?.addEventListener("click", closeBookModal);
bookModalOverlay?.addEventListener("click", (event) => {
  if (event.target === bookModalOverlay) {
    closeBookModal();
  }
});

bookPdfInput?.addEventListener("change", () => {
  const selectedFile = bookPdfInput.files?.[0];
  bookPdfHint.textContent = selectedFile
    ? `Selected PDF: ${selectedFile.name}`
    : currentBookPdfValue
      ? `Current PDF: ${getPdfFileName(currentBookPdfValue)}`
      : "PDF is required for new books.";
});

bookImageInput?.addEventListener("change", () => {
  const file = bookImageInput.files?.[0];

  resetBookObjectUrl();

  if (!file) {
    updateBookPreview(resolveBookImage(currentBookImageValue));
    return;
  }

  currentBookObjectUrl = URL.createObjectURL(file);
  updateBookPreview(currentBookObjectUrl);
});

bookForm?.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!validateBookForm()) {
    return;
  }

  const id = document.getElementById("bookId").value;
  bookModalSubmit.disabled = true;
  bookModalSubmit.textContent = "Saving...";

  try {
    const payload = buildBookPayload();

    if (id) {
      await onUpdateBook(id, payload);
    } else {
      await onCreateBook(payload);
    }

    closeBookModal();
    await loadBooks();
  } catch (error) {
    alert(error.message);
  } finally {
    bookModalSubmit.disabled = false;
    bookModalSubmit.textContent = id ? "Save Changes" : "Create Book";
  }
});

document.getElementById("deleteBookModalClose")?.addEventListener("click", closeDeleteBookModal);
document.getElementById("deleteBookModalCancel")?.addEventListener("click", closeDeleteBookModal);
deleteBookModalOverlay?.addEventListener("click", (event) => {
  if (event.target === deleteBookModalOverlay) {
    closeDeleteBookModal();
  }
});

deleteBookModalConfirm?.addEventListener("click", async () => {
  if (!pendingBookDeleteId) {
    return;
  }

  deleteBookModalConfirm.disabled = true;
  deleteBookModalConfirm.textContent = "Deleting...";

  try {
    await onDeleteBook(pendingBookDeleteId);
    closeDeleteBookModal();
    await loadBooks();
  } catch (error) {
    alert(error.message);
  } finally {
    deleteBookModalConfirm.disabled = false;
    deleteBookModalConfirm.textContent = "Yes, Delete";
  }
});

if (themeToggle) {
  applyTheme(localStorage.getItem(THEME_KEY) || "light");
}

if (document.getElementById("section-dashboard")) {
  if (ensureAdminAccess()) {
    loadData();
    renderStudents();
    showSection("dashboard");
  }
}

async function loadData() {
  const tbody = document.getElementById("dashboard-activity-tbody");
  tbody.innerHTML = `<tr><td colspan="5" class="empty-row">Loading...</td></tr>`;
  const token = localStorage.getItem("token");

  if (!token) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty-row">Token topilmadi. Qayta login qiling.</td></tr>`;
    redirectToLogin();
    return;
  }

  const response = await fetch(BASE_URL + "/api/admin/dashboard", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      redirectToLogin();
    }

    tbody.innerHTML = `<tr><td colspan="5" class="empty-row">${data.message || "Dashboard yuklanmadi."}</td></tr>`;
    return;
  }

  renderDashboardActivity(data.data.activity);
  renderStudents(data.data.students);
  renderGroups(data.data.groups);
}

// --- STUDENT MODAL LOGIC ---
const openStudentModalBtn = document.getElementById("openStudentModalBtn");
const dashboardAddStudentBtn = document.getElementById("dashboardAddStudentBtn");
const studentModalOverlay = document.getElementById("studentModalOverlay");
const studentModalClose = document.getElementById("studentModalClose");
const studentModalCancel = document.getElementById("studentModalCancel");
const studentForm = document.getElementById("studentForm");
const studentModalSubmit = document.getElementById("studentModalSubmit");

function closeStudentModal() {
  if(studentModalOverlay) studentModalOverlay.classList.remove("open");
  if(studentForm) studentForm.reset();
  document.querySelectorAll("#studentForm .field-error").forEach(el => el.textContent = "");
  document.querySelectorAll("#studentForm input, #studentForm select").forEach(el => el.classList.remove("invalid"));
}

async function populateStudentGroups() {
  const groupSelect = document.getElementById("studentGroup");
  if (!groupSelect) return;
  groupSelect.innerHTML = '<option value="">Select a group</option>';
  try {
    const token = localStorage.getItem("token");
    const response = await fetch(BASE_URL + "/api/admin/dashboard", {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (response.ok) {
      const data = await response.json();
      const groups = data.data?.groups || [];
      groups.forEach(group => {
        const option = document.createElement("option");
        option.value = group.id;
        option.textContent = group.label || group.level;
        groupSelect.appendChild(option);
      });
    }
  } catch (err) {
    console.error("Failed to load groups for modal", err);
  }
}

function openStudentModal(student = null) {
  populateStudentGroups().then(() => {
    if (student && student.id) {
      document.getElementById("studentGroup").value = student.groupId || "";
    }
  });
  
  const title = document.querySelector("#studentModal .modal-header h3");
  const studentForm = document.getElementById("studentForm");
  const studentModalSubmit = document.getElementById("studentModalSubmit");

  if (student && student.id) {
    editingStudentId = student.id;
    document.getElementById("studentUsername").value = student.username || "";
    document.getElementById("studentFullName").value = student.fullName || "";
    
    // Check if email field exists (it might not be in the form)
    const emailField = document.getElementById("studentEmail");
    if(emailField) emailField.value = student.email || "";
    
    document.getElementById("studentPhone").value = student.phone || "";
    document.getElementById("studentParentPhone").value = student.parentPhone || "";
    document.getElementById("studentStatus").value = student.status || "Active";
    
    document.getElementById("studentPassword").required = false;
    document.getElementById("studentParentPassword").required = false;
    
    if (title) title.textContent = "Edit Student";
    if (studentModalSubmit) studentModalSubmit.textContent = "Save Changes";
  } else {
    editingStudentId = null;
    if (studentForm) studentForm.reset();
    document.getElementById("studentPassword").required = true;
    document.getElementById("studentParentPassword").required = true;
    if (title) title.textContent = "Add Student";
    if (studentModalSubmit) studentModalSubmit.textContent = "Create Student";
  }
  
  studentModalOverlay.classList.add("open");
}

if (openStudentModalBtn) {
  openStudentModalBtn.addEventListener("click", openStudentModal);
}
if (dashboardAddStudentBtn) {
  dashboardAddStudentBtn.addEventListener("click", openStudentModal);
}

if (studentModalClose) studentModalClose.addEventListener("click", closeStudentModal);
if (studentModalCancel) studentModalCancel.addEventListener("click", closeStudentModal);
if (studentModalOverlay) {
  studentModalOverlay.addEventListener("click", (e) => {
    if (e.target === studentModalOverlay) closeStudentModal();
  });
}

function setStudentFieldError(fieldId, errId, msg) {
  document.getElementById(fieldId).classList.add("invalid");
  document.getElementById(errId).textContent = msg;
}

if (studentForm) {
  studentForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    // Clear errors
    document.querySelectorAll("#studentForm .field-error").forEach(el => el.textContent = "");
    document.querySelectorAll("#studentForm input, #studentForm select").forEach(el => el.classList.remove("invalid"));

    const fullName = document.getElementById("studentFullName").value.trim();
    const username = document.getElementById("studentUsername").value.trim();
    const password = document.getElementById("studentPassword").value;
    const parentPassword = document.getElementById("studentParentPassword").value;
    const phone = document.getElementById("studentPhone").value.trim();
    const parentPhone = document.getElementById("studentParentPhone").value.trim();
    const groupId = document.getElementById("studentGroup").value;
    const status = document.getElementById("studentStatus").value;

    let valid = true;
    const payload = {};
    if (status) payload.status = status;
    if (groupId) payload.groupId = groupId;

    if (!editingStudentId) {
      if (!fullName) { setStudentFieldError("studentFullName", "student-err-fullname", "Full Name is required."); valid = false; }
      else payload.fullName = fullName;
      
      if (!username) { setStudentFieldError("studentUsername", "student-err-username", "Username is required."); valid = false; }
      else payload.username = username;
      
      if (!password || password.length < 6) { setStudentFieldError("studentPassword", "student-err-password", "Password must be at least 6 characters."); valid = false; }
      else payload.password = password;
      
      if (!parentPassword || parentPassword.length < 6) { setStudentFieldError("studentParentPassword", "student-err-parent-password", "Parent's Password must be at least 6 characters."); valid = false; }
      else payload.parentPassword = parentPassword;
      
      if (!phone) { setStudentFieldError("studentPhone", "student-err-phone", "Phone is required."); valid = false; }
      else payload.phone = phone;
      
      if (!parentPhone) { setStudentFieldError("studentParentPhone", "student-err-parent-phone", "Parent Phone is required."); valid = false; }
      else payload.parentPhone = parentPhone;
      
      if (!groupId) { setStudentFieldError("studentGroup", "student-err-group", "Group is required."); valid = false; }
    } else {
      if (fullName) payload.fullName = fullName;
      if (username) payload.username = username;
      if (phone) payload.phone = phone;
      if (parentPhone) payload.parentPhone = parentPhone;
      
      if (password) {
        if (password.length < 6) { setStudentFieldError("studentPassword", "student-err-password", "Password must be at least 6 characters."); valid = false; }
        else payload.password = password;
      }
      if (parentPassword) {
        if (parentPassword.length < 6) { setStudentFieldError("studentParentPassword", "student-err-parent-password", "Parent's Password must be at least 6 characters."); valid = false; }
        else payload.parentPassword = parentPassword;
      }
    }

    if (!valid) return;

    studentModalSubmit.disabled = true;
    studentModalSubmit.textContent = editingStudentId ? "Saving..." : "Creating...";

    try {
      const token = localStorage.getItem("token");
      const url = editingStudentId ? BASE_URL + "/api/students/" + editingStudentId : BASE_URL + "/api/students";
      const method = editingStudentId ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || "Failed to create student.");
      }

      if (typeof showToast !== 'undefined') {
        showToast(editingStudentId ? "Student updated successfully!" : "Student created successfully!", "success");
      } else {
        alert(editingStudentId ? "Student updated successfully!" : "Student created successfully!");
      }
      closeStudentModal();
      loadData();
    } catch (error) {
      if (typeof showToast !== 'undefined') {
        showToast(error.message, "error");
      } else {
        alert(error.message);
      }
    } finally {
      studentModalSubmit.disabled = false;
      studentModalSubmit.textContent = editingStudentId ? "Save Changes" : "Create Student";
    }
  });
}

window.editStudent = function(id) {
  const student = currentStudents.find(s => s.id === id);
  if (student) openStudentModal(student);
};

let studentToDelete = null;
window.deleteStudent = function(id) {
  studentToDelete = id;
  const modal = document.getElementById("deleteStudentModalOverlay");
  if (modal) modal.classList.add("open");
};

const deleteStudentConfirmBtn = document.getElementById("deleteStudentModalConfirm");
const deleteStudentCancelBtn = document.getElementById("deleteStudentModalCancel");
const deleteStudentCloseBtn = document.getElementById("deleteStudentModalClose");

function closeDeleteStudentModal() {
  studentToDelete = null;
  const modal = document.getElementById("deleteStudentModalOverlay");
  if (modal) modal.classList.remove("open");
}

if (deleteStudentCancelBtn) deleteStudentCancelBtn.addEventListener("click", closeDeleteStudentModal);
if (deleteStudentCloseBtn) deleteStudentCloseBtn.addEventListener("click", closeDeleteStudentModal);

if (deleteStudentConfirmBtn) {
  deleteStudentConfirmBtn.addEventListener("click", async () => {
    if (!studentToDelete) return;
    
    // show loading state on button
    const oldText = deleteStudentConfirmBtn.textContent;
    deleteStudentConfirmBtn.textContent = "Deleting...";
    deleteStudentConfirmBtn.disabled = true;

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(BASE_URL + "/api/students/" + studentToDelete, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Failed to delete student");
      
      if (typeof showToast !== 'undefined') {
        showToast("Student deleted successfully", "success");
      } else {
        alert("Student deleted successfully");
      }
      
      closeDeleteStudentModal();
      loadData();
    } catch (e) {
      if (typeof showToast !== 'undefined') {
        showToast(e.message, "error");
      } else {
        alert(e.message);
      }
    } finally {
      deleteStudentConfirmBtn.textContent = oldText;
      deleteStudentConfirmBtn.disabled = false;
    }
  });
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) {
    alert(message);
    return;
  }
  const toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  
  let icon = '&#10004;';
  if (type === 'error') icon = '&#10006;';
  if (type === 'info') icon = '&#8505;';
  
  toast.innerHTML = `<div class="toast-icon">${icon}</div><div class="toast-message">${message}</div>`;
  container.appendChild(toast);
  
  setTimeout(() => {
    toast.classList.add('toast-hiding');
    toast.addEventListener('animationend', () => {
      toast.remove();
    });
  }, 3000);
}
